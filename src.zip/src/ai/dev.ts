import { config } from 'dotenv';
config();

import '@/ai/flows/recipe-generator.ts';